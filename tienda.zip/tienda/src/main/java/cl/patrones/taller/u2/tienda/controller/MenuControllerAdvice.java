package cl.patrones.taller.u2.tienda.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import cl.patrones.taller.u2.catalogo.domain.Categoria;
import cl.patrones.taller.u2.catalogo.service.CategoriaService;
import cl.patrones.taller.u2.tienda.menu.CategoriaMenuAdapter;
import cl.patrones.taller.u2.tienda.menu.EnlaceMenu;
import cl.patrones.taller.u2.tienda.menu.ItemMenu;

@ControllerAdvice
public class MenuControllerAdvice {

	private CategoriaService categoriaService;

	public MenuControllerAdvice(CategoriaService categoriaService) {
		super();
		this.categoriaService = categoriaService;
	}

	@ModelAttribute("menu")
	public List<ItemMenu> menu() {
		return List.of(
			new EnlaceMenu("Inicio", "/"),
			new EnlaceMenu("Categorias", "/categoria", construirCategorias()),
			new EnlaceMenu("Ubicacion", "/ubicacion"),
			new EnlaceMenu("Contacto", "/contacto")
		);
	}

	private List<ItemMenu> construirCategorias() {
		Map<Long, List<Categoria>> categoriasPorPadre = new LinkedHashMap<>();
		categoriaService.getCategorias().stream()
			.sorted(Comparator.comparing(Categoria::getId))
			.forEach(categoria -> {
				Long padreId = categoria.getPadre() != null ? categoria.getPadre().getId() : 0L;
				categoriasPorPadre.computeIfAbsent(padreId, k -> new ArrayList<>()).add(categoria);
			});
		return construirHijos(0L, categoriasPorPadre);
	}

	private List<ItemMenu> construirHijos(Long padreId, Map<Long, List<Categoria>> categoriasPorPadre) {
		return categoriasPorPadre.getOrDefault(padreId, List.of()).stream()
			.map(categoria -> (ItemMenu) new CategoriaMenuAdapter(categoria, construirHijos(categoria.getId(), categoriasPorPadre)))
			.toList();
	}
	
}
