package cl.patrones.taller.u2.catalogo.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import cl.patrones.taller.u2.catalogo.domain.Clasificacion;
import cl.patrones.taller.u2.catalogo.repository.ClasificacionRepository;

@Service
public class ClasificacionServiceImpl implements ClasificacionService {

	private ClasificacionRepository repository;

	public ClasificacionServiceImpl(ClasificacionRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public List<Clasificacion> getClasificaciones() {
		return repository.findAll();
	}

	@Override
	public Optional<Clasificacion> getClasificacionPorSku(String sku) {
		return repository.findFirstBySku(sku);
	}

	@Override
	public List<Clasificacion> getClasificacionesPorCategoriaId(Long categoriaId) {
		return repository.findByCategoriaId(categoriaId);
	}

	@Override
	public List<Clasificacion> getClasificacionesPorCategoriaIds(Collection<Long> categoriaIds) {
		if (categoriaIds == null || categoriaIds.isEmpty()) {
			return List.of();
		}
		return repository.findByCategoriaIdIn(categoriaIds);
	}

}
