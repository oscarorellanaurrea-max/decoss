package cl.patrones.taller.u2.tienda.adapter;

import cl.patrones.taller.u2.bodegaje.domain.Producto;
import cl.patrones.taller.u2.catalogo.domain.Aviso;
import cl.patrones.taller.u2.catalogo.domain.Categoria;

public class ProductoAvisoAdapter extends Aviso {

	public ProductoAvisoAdapter(Producto producto, Categoria categoria) {
		super(
			producto.getId(),
			producto.getSku(),
			producto.getNombre(),
			calcularPrecio(producto.getCosto()),
			producto.getImagen(),
			calcularStock(producto),
			categoria
		);
	}

	private static Long calcularPrecio(Long costo) {
		if (costo == null) {
			return 0L;
		}
		return Math.round(costo * 1.3d);
	}

	private static int calcularStock(Producto producto) {
		return producto.getStocks().stream().mapToInt(stock -> stock.getCantidad()).sum();
	}

}
