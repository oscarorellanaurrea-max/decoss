package cl.patrones.taller.u2.tienda.menu;

import java.util.List;

import cl.patrones.taller.u2.catalogo.domain.Categoria;
import cl.patrones.taller.u2.tienda.menu.util.Slugger;

public class CategoriaMenuAdapter implements ItemMenu {

	private Categoria categoria;
	private List<ItemMenu> hijos;

	public CategoriaMenuAdapter(Categoria categoria, List<ItemMenu> hijos) {
		super();
		this.categoria = categoria;
		this.hijos = hijos;
	}

	@Override
	public String getTexto() {
		return categoria.getNombre();
	}

	@Override
	public String getSlug() {
		return Slugger.toSlug(categoria.getNombre());
	}

	@Override
	public String getEnlace() {
		return "/categoria/" + categoria.getId() + "/" + getSlug();
	}

	@Override
	public boolean tieneHijos() {
		return !hijos.isEmpty();
	}

	@Override
	public List<? extends ItemMenu> getHijos() {
		return hijos;
	}

}
