package cl.patrones.taller.u2.catalogo.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import cl.patrones.taller.u2.catalogo.domain.Clasificacion;

public interface ClasificacionService {

	List<Clasificacion> getClasificaciones();
	Optional<Clasificacion> getClasificacionPorSku(String sku);
	List<Clasificacion> getClasificacionesPorCategoriaId(Long categoriaId);
	List<Clasificacion> getClasificacionesPorCategoriaIds(Collection<Long> categoriaIds);

}
