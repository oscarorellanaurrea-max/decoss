package cl.patrones.taller.u2.tienda.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import cl.patrones.taller.u2.bodegaje.service.BodegajeService;
import cl.patrones.taller.u2.catalogo.domain.Aviso;
import cl.patrones.taller.u2.catalogo.domain.Categoria;
import cl.patrones.taller.u2.catalogo.service.CategoriaService;
import cl.patrones.taller.u2.catalogo.service.ClasificacionService;
import cl.patrones.taller.u2.tienda.adapter.ProductoAvisoAdapter;

@Service
public class AvisoServiceImpl implements AvisoService {

	private BodegajeService bodegajeService;
	private ClasificacionService clasificacionService;
	private CategoriaService categoriaService;

	public AvisoServiceImpl(
			BodegajeService bodegajeService,
			ClasificacionService clasificacionService,
			CategoriaService categoriaService
	) {
		super();
		this.bodegajeService = bodegajeService;
		this.clasificacionService = clasificacionService;
		this.categoriaService = categoriaService;
	}

	@Override
	public List<Aviso> getAvisos() {
		Map<String, Categoria> categoriasPorSku = clasificacionService.getClasificaciones().stream()
			.collect(
				Collectors.toMap(
					clasificacion -> clasificacion.getSku(),
					clasificacion -> clasificacion.getCategoria(),
					(categoria1, categoria2) -> categoria1,
					LinkedHashMap::new
				)
			);

		return bodegajeService.getProductos().stream()
			.map(producto -> adaptarProducto(producto, categoriasPorSku))
			.toList();
	}

	@Override
	public List<Aviso> getAvisosPorCategoria(Long categoriaId) {
		List<Long> categoriaIds = getCategoriaIds(categoriaId);
		Map<String, Categoria> categoriasPorSku = clasificacionService.getClasificacionesPorCategoriaIds(categoriaIds).stream()
			.collect(
				Collectors.toMap(
					clasificacion -> clasificacion.getSku(),
					clasificacion -> clasificacion.getCategoria(),
					(categoria1, categoria2) -> categoria1,
					LinkedHashMap::new
				)
			);

		if (categoriasPorSku.isEmpty()) {
			return List.of();
		}

		String[] skus = categoriasPorSku.keySet().toArray(String[]::new);
		return bodegajeService.getProductosBySku(skus).stream()
			.map(producto -> adaptarProducto(producto, categoriasPorSku))
			.toList();
	}

	private Aviso adaptarProducto(cl.patrones.taller.u2.bodegaje.domain.Producto producto, Map<String, Categoria> categoriasPorSku) {
		return new ProductoAvisoAdapter(producto, categoriasPorSku.get(producto.getSku()));
	}

	private List<Long> getCategoriaIds(Long categoriaId) {
		Map<Long, List<Categoria>> categoriasPorPadre = new LinkedHashMap<>();
		categoriaService.getCategorias().forEach(categoria -> {
			Long padreId = categoria.getPadre() != null ? categoria.getPadre().getId() : 0L;
			categoriasPorPadre.computeIfAbsent(padreId, k -> new ArrayList<>()).add(categoria);
		});

		List<Long> categoriaIds = new ArrayList<>();
		cargarCategoriaIds(categoriaId, categoriasPorPadre, categoriaIds);
		return categoriaIds;
	}

	private void cargarCategoriaIds(Long categoriaId, Map<Long, List<Categoria>> categoriasPorPadre, List<Long> categoriaIds) {
		categoriaIds.add(categoriaId);
		for (Categoria categoria : categoriasPorPadre.getOrDefault(categoriaId, List.of())) {
			cargarCategoriaIds(categoria.getId(), categoriasPorPadre, categoriaIds);
		}
	}

}
